# Grand Slam Multimodal Benchmark (V29 Statistical)

A rigorously statistical benchmark for evaluating multimodal embedding models (Vision-Language Models) on the MS-COCO Karpathy split. This project goes beyond simple accuracy metrics by implementing bootstrap sampling, permutation tests, and detailed failure analysis to provide a deep understanding of model performance.

## 🎯 Key Features

*   **Statistical Rigor**: Implements **1000-iteration bootstrap sampling** to provide true 95% confidence intervals for all metrics. No more ambiguous "±0.0" results.
*   **Significance Testing**: Uses permutation tests to determine if performance differences between models are statistically significant (p < 0.05).
*   **Symmetric Protocols**: Evaluates both standard (1-to-5) and symmetric (1-to-1) Image-to-Text retrieval protocols to expose biases in multi-caption evaluation.
*   **Failure Analysis**: automatically categorizes queries by complexity (spatial, color, counting) and object category (person, vehicle, animal, etc.) to pinpoint exactly *where* models fail.
*   **Robust Evaluation**: Handles connection instability and image corruption gracefully with a robust caching and downloading mechanism.

## 🚀 Getting Started

### Prerequisites

*   Python 3.10+
*   CUDA-capable GPU (Recommended: 24GB+ VRAM for dense models, 48GB+ for ColPali)
*   Dependencies:
    ```bash
    pip install torch transformers datasets pillow pandas tqdm numpy scikit-learn requests
    ```
    *(Note: `colpali_engine` is required for testing ColPali models)*

### Usage

The main entry point is `main.py` (which runs the V29 Statistical Benchmark).

**Standard Run (Statistical Mode):**
Runs 1000 bootstrap iterations for rigorous confidence intervals. This takes time!
```bash
python main.py --bootstrap-iterations 1000 --batch-size 32
```

**Quick Test (Debug Mode):**
Reduces iterations for a faster sanity check.
```bash
python main.py --bootstrap-iterations 100 --batch-size 32 --models "OpenAI-CLIP-L"
```

**Arguments:**
*   `--models`: Comma-separated list of models to test (default: "all").
    *   Options: `ColPali-v1.3`, `SigLIP-400M`, `LAION-CLIP-H`, `Jina-CLIP-v1`, `MetaCLIP-H14`, `OpenAI-CLIP-L`, `Apple-DFN5B-H`
*   `--bootstrap-iterations`: Number of resampling iterations (default: 1000).
*   `--batch-size`: Batch size for dense models (default: 32).
*   `--output`: Output CSV filename.

## 📈 Methodology & Metrics

### 1. Text-to-Image (T2I) Retrieval
*   **Task:** Given a caption, find the exact corresponding image among 5,000 candidates.
*   **Metric:** **Recall@1 (R@1)** - Percentage of times the correct image is the #1 rank.
*   **Significance:** The hardest and most precise metric for understanding.

### 2. Image-to-Text (I2T) Retrieval
*   **Standard Protocol:** Given an image, find *any* of its 5 valid captions among 25,000 candidates.
*   **Symmetric Protocol:** Given an image, find its *specific* single caption (1-to-1 mapping), allowing direct comparison with T2I.

### 3. Failure Analysis
The benchmark automatically analyzes queries based on:
*   **Complexity:** Presence of spatial relations ("next to"), colors, or counting terms.
*   **Category:** Performance breakdown by COCO supercategories (e.g., "Food", "Vehicle", "Animal").

## 📁 Project Structure

*   `main.py`: **Primary entry point.** Runs the full V29 statistical benchmark.
*   `COCO_BENCHMARK_REPORT_FINAL.md`: Detailed analysis and report of the benchmark results.
*   `benchmark_v29_statistical_results.csv`: Output file containing the raw results (generated after running).
*   `coco_images/`: Local cache for downloaded COCO images.

## 📜 Citation

If you use this benchmark or results, please cite:

```bibtex
@techreport{coco_benchmark_2025,
  title={Benchmark of 7 Multimodal Embedding Models on MS-COCO Karpathy and Winoground},
  year={2025},
  institution={Independent Research}
}
```
